<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\Likes;

class Post extends Model
{
    use HasFactory;
    protected $fillable = ['title', 'message'];

    public function likes(): HasMany
    {
        // return $this->hasMany(Like::class);
         return $this->hasMany(Likes::class);
    }


    public function isLikedBy($likerName)
    {
        // Check if the likes relationship contains the liker_name
        return $this->likes->contains('liker_name', $likerName);
    }




    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

}
