<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class ProfileController extends Controller
{
    public function show(User $user)
    {
        // Display the user's profile and their posts
    }

    public function edit(User $user)
    {
        // Show the form to edit the user's profile
    }

    public function update(Request $request, User $user)
    {
        // Validate and update the user's profile
    }
}
