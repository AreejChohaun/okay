<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Likes;    

class PostController extends Controller
{
   
    public function index()
    {
        // $posts = Post::all();
        // $posts = Post::orderBy('created_at', 'desc')->get();
        $posts = Post::withCount('comments')->orderBy('created_at', 'desc')->get();
        return view('posts.index', compact('posts'));
    }
    public function hasLiked($post, $userIdentifier)
    {
        foreach ($post->likes as $like) {
            if ($like->liker_name === $userIdentifier) {
                return true;
            }
        }
        return false;
    }


   // Create a new post
    public function create()
    {
        return view('posts.create');
    }
    public function like(Request $request, Post $post)
    {
        // Check if the user's name (liker_name) is provided in the request
        $likerName = $request->input('liker_name');

        if (empty($likerName)) {
            return back()->with('error', 'Please enter your name to like the post.');
        }

        // Check if the user (by name) has already liked the post
        if ($post->isLikedBy($likerName)) {
            return back()->with('error', 'You have already liked this post.');
        }

        // Create a new like record in the database
        $a = Likes::create([
            'post_id' => $post->id,
            'liker_name' => $likerName,
        ]);

        return back()->with('success', 'You liked the post.');
    }

    // Store a new post
    public function store(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'title' => 'required|string|min:3|max:255',
            'author' => 'required|string|regex:/^[^0-9]+$/|max:255',
            'message' => 'required|min:5|string',
        ]);

        // Create a new post using the validated data
        $post = new Post();
        $post->title = $validatedData['title'];
        $post->author = $validatedData['author'];
        $post->message = $validatedData['message'];
        $post->save();

        // Redirect to the post's details page
        // return redirect()->route('posts.show', $post->id);
        return redirect()->route('posts.index')->with('success', 'Post created successfully.');
    }

    // Show a specific post
    public function show($id)
    {
        // Retrieve the post by its ID
        $post = Post::findOrFail($id);
        $comments = $post->comments; // Retrieve comments associated with the post
        return view('posts.show', compact('post', 'comments'));
    }

    // Edit an existing post
    public function edit($id)
    {
        // Retrieve the post for editing
        $post = Post::findOrFail($id);

        return view('posts.edit', compact('post'));
    }

    // Update an existing post
    public function update(Request $request, $id)
    {
        /*
        // Validate the request data
        $validatedData = $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'required|string|max:255',
            'message' => 'required|string',
        ]);

        // Find the post by its ID
        $post = Post::findOrFail($id);

        // Update the post attributes
        $post->title = $validatedData['title'];
        $post->author = $validatedData['author'];
        $post->message = $validatedData['message'];
        $post->save();

        // Redirect to the post's details page
        return redirect()->route('posts.show', $post->id)->with('success', 'Post updated successfully.'); */
        $post = Post::findOrFail($id);

        // Validate the form data
        $validatedData = $request->validate([
            'title' => 'required|string|max:255',
            'message' => 'required|string',
        ]);

        // Update the post with the new data
        $post->update([
            'title' => $validatedData['title'],
            'message' => $validatedData['message'],
        ]);

        // return redirect()->route('posts.show', ['post' => $post->id])->with('success', 'Post updated successfully.');
        return redirect()->route('posts.show', ['id' => $post->id])->with('success', 'Post updated successfully.');

    }

    // Delete a post
    public function destroy($id)
    {
        // Find the post by its ID and delete it
        // $post = Post::findOrFail($id);
        // $post->delete();

        // // Redirect to the post listing page
        // return redirect()->route('posts.index');
        $post = Post::findOrFail($id);

        // Delete associated comments
        $post->comments()->delete();
        $post->likes()->delete();

        // Delete the post
        $post->delete();

        return redirect()->route('posts.index')->with('success', 'Post and associated comments deleted successfully.');
    }



}


