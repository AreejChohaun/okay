<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Comment;
use App\Models\Likes;

class CommentController extends Controller
{
    //
    public function store(Request $request, Post $post)
    {
        // Validate the form data
        $request->validate([
            'author' => 'required|string|max:255',
            'message' => 'required|string',
        ]);

        // Create a new comment associated with the post
        $comment = new Comment([
            'author' => $request->input('author'),
            'message' => $request->input('message'),
        ]);

        $post->comments()->save($comment);

        // Redirect back to the details page for that post
        return redirect()->route('posts.show', ['id' => $post->id])->with('success', 'Comment added successfully.');
    }

    public function reply(Request $request, Comment $comment)
    {
        $this->validate($request, [
            'message' => 'required|min:3', // Add any validation rules you need
        ]);

        Comment::create([
            'message' => $request->input('message'),
            'author' => $request->input('author'), // Assuming you have user authentication
            'post_id' => $comment->post_id,
            'parent_comment_id' => $request->input('parent_comment_id'),
        ]);

        return back()->with('success', 'Reply added successfully.');
    }


    public function edit(Comment $comment)
    {
        // Show the form to edit a comment
    }

    public function update(Request $request, Comment $comment)
    {
        // Validate and update the comment
    }

    public function destroy(Comment $comment)
    {
        // Delete the comment
    }
}
