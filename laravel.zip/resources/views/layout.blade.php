<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <!-- Add your CSS links here -->
     <link rel="stylesheet" type="text/css" href="{{asset('css/style.css')}}">
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="http://localhost/laravel/">Home</a></li>
                <li><a href="http://localhost/laravel/posts">Posts</a></li>
                <li><a href="http://localhost/laravel/users">Users List</a></li>
            </ul>
        </nav>
    </header>

    <main>
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-warning">
                {{ session('error') }}
            </div>
        @endif
        @yield('content')
    </main>

    <footer>
        <!-- Footer content goes here -->
        <p>&copy; {{ date('Y') }} Your Website Name</p>
    </footer>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.comment-reply-button').on('click', function() {
                $(this).siblings('.replies').toggle();
            });
        });

    </script>
</body>
</html>
