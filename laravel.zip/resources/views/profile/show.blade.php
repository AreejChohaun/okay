@extends('layouts.app')

@section('title', $user->name)

@section('content')
    <h1>User Profile: {{ $user->name }}</h1>
    <!-- Display user profile information here -->
    <p>Email: {{ $user->email }}</p>
    <p>Joined: {{ $user->created_at }}</p>
    <!-- Display user's posts here -->
    @foreach($user->posts as $post)
        <div class="post">
            <h2>{{ $post->title }}</h2>
            <p>Date: {{ $post->created_at }}</p>
            <p>{{ $post->message }}</p>
            <!-- Display comments for this post -->
            <ul>
                @foreach($post->comments as $comment)
                    <li>{{ $comment->author }}: {{ $comment->message }}</li>
                @endforeach
            </ul>
        </div>
    @endforeach
@endsection
