@extends('layouts.app')

@section('title', 'Home')

@section('content')
    <h1>Home</h1>
    <!-- Display a list of posts here -->
    @foreach($posts as $post)
        <div class="post">
            <h2>{{ $post->title }}</h2>
            <p>Author: {{ $post->author }}</p>
            <p>Date: {{ $post->created_at }}</p>
            <p>{{ $post->message }}</p>
            <!-- Display comments for this post -->
            <ul>
                @foreach($post->comments as $comment)
                    <li>{{ $comment->author }}: {{ $comment->message }}</li>
                @endforeach
            </ul>
        </div>
    @endforeach
@endsection
