@extends('layout')

@section('title', "Posts by {$user->name}")

@section('content')
    <h1>Posts by {{ $user->name }}</h1>

    <ul>
        @foreach ($posts as $post)
            <li>{{ $post->title }}</li>
        @endforeach
    </ul>
@endsection
