@foreach ($replies as $reply)
    <div class="comment-reply">
        <p>{{ $reply->message }}</p>
        <p>Posted by: {{ $reply->author }}</p>
        <button class="toggle-replies">Show Replies</button>
        <div class="replies">
            @include('posts.partials.comment_replies', ['replies' => $reply->replies])
        </div>
    </div>
@endforeach
