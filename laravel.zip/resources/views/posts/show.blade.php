@extends('layout')

@section('title', $post->title)

@section('content')

    <a class="editpost" href="{{ route('posts.edit', $post->id) }}">Edit Post</a>

    <form class="deletepost" method="POST" action="{{ route('posts.destroy', $post->id) }}">
        @csrf
        @method('DELETE') <!-- Use DELETE method for deletion -->
        <button type="submit" onclick="return confirm('Are you sure you want to delete this post?')">Delete Post</button>
    </form>

    <a class="backtoposts" href="{{ route('posts.index') }}">Back to All Posts</a>

    <h1>{{ $post->title }}</h1>
    <p>Author: {{ $post->author }}</p>
    <p>{{ $post->message }}</p>
    <p>Posted on: {{ $post->post_date }}</p>

    <div class="post">
        <!-- Display post content -->

        <p>Likes: {{ $post->likes ? $post->likes->count() : 0 }}</p>

        <form method="POST" action="{{ route('posts.like', $post->id) }}">
            @csrf
            <br>
            <input type="text" name="liker_name" placeholder="Your Name">
            <br>
            <br>

            <button type="submit" class="buttonpadding">Like</button>
        </form>
    </div>

     <div class="comments_add">
        <!-- Comment Creation Form -->
        <h2>Add a Comment</h2>
        <form method="POST" action="{{ route('comments.store', ['post' => $post->id]) }}">
            @csrf
            <label for="author">Author:</label>
            <input type="text" name="author" id="author" required>

            <label for="message">Comment:</label>
            <textarea name="message" id="message" rows="4" required></textarea>

            <button type="submit" class="buttonpadding">Add Comment</button>
        </form>
    </div>

    <br>


    <h2>Comments:</h2>

    @if ($comments->count() > 0)
        <ul>
            @foreach ($comments as $comment)
                @if(!$comment->parent_comment_id)

                <div class="comment">

                    <p>{{ $comment->message }}</p>
                    <p>Posted by: {{ $comment->author }}</p>
                    <button class="comment-reply-button" data-toggle-replies>Show Replies</button>
                    <br>
                    <div class="replies" style="display: none;">
                        @include('posts.partials.comment_replies', ['replies' => $comment->replies])
                    </div>

                    <br>
                    <!-- Reply Form -->
                    <form method="POST" action="{{ route('comments.reply', $comment->id) }}">
                        @csrf
                        <div class="form-group">
                            <input name="author" class="custominput form-control" placeholder="author" value="{{ old('author') }}" >
                             @error('title')
                                <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="form-group">
                            <textarea name="message" class="form-control" rows="3" placeholder="Write a reply">{{ old('message') }}</textarea>
                            @error('message')
                                <div class="alert alert-danger">{{ $message }}</div>
                            @enderror
                        </div>
                        <input type="hidden" name="parent_comment_id" value="{{ $comment->id }}">
                        <button type="submit" class="btn btn-primary buttonpadding" style="display: block;margin: 0 auto;">Reply</button>
                    </form>
                
                </div>
                @endif
            @endforeach
        </ul>
    @else
      <p>No comments yet.</p>
    @endif

   

    
@endsection
