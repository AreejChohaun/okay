
@extends('layout')

@section('title', 'Edit Post')

@section('content')
    <h1>Edit Post</h1>

    <form method="POST" action="{{ route('posts.update', ['post' => $post->id]) }}">
        @csrf
        @method('PUT') <!-- Use PUT method for updating -->

        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="{{ $post->title }}" required>

        <label for="message">Message:</label>
        <textarea name="message" id="message" rows="4" required>{{ $post->message }}</textarea>

        <button type="submit" class="buttonpadding">Update Post</button>
    </form>
@endsection


<!-- extends('layout')

section('title', 'Edit Post')

section('content')
    <h1>Edit Post</h1>

    <form method="POST" action="{{ route('posts.update', $post->id) }}">
        @csrf
        @method('PATCH')

        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="{{ $post->title }}" required>

        <label for="author">Author:</label>
        <input type="text" name="author" id="author" value="{{ $post->author }}" required>

        <label for="message">Message:</label>
        <textarea name="message" id="message" rows="4" required>{{ $post->message }}</textarea>

        <button type="submit">Update Post</button>
    </form>
endsection   -->


