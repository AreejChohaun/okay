@extends('layout')

@section('title', 'All Posts')

@section('content')

   <h1 class="homeheading">All Posts</h1>
   <a href="{{ route('posts.create') }}" class="homenewpost custombutton">Create New Post</a>
   <div class="clear"></div>
    

    @foreach ($posts as $post)
        <div class="post">
            <h2> <strong>{{ $post->title }}</strong> - <small>{{ $post->comments_count }} comments</small></h2>  
            <p>Author: {{ $post->author }}</p>
            <p>{{ $post->message }}</p>
            <p>Posted on: {{ $post->post_date }}</p>
            <a href="{{ route('posts.show', $post->id) }}" class="custombutton">View Details</a>
        </div>
    @endforeach

    
@endsection