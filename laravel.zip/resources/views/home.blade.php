@extends('layout')

@section('title', 'Home Page')

@section('content')
    <!-- Your home page content goes here -->
    <h2>Welcome to Our Website</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. ...</p>
@endsection
