<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\CommentController;
use App\Http\Controllers\UserController;
// use App\Models\Like;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


// Define the route for the user list page
Route::get('/users', [UserController::class, 'index'])->name('users.index');
// Define the route for viewing user posts
Route::get('/users/{user}', [UserController::class, 'show'])->name('users.show');


Route::resource('posts', PostController::class);
Route::get('/', [PostController::class, 'index'])->name('posts.index');
Route::get('/posts/{id}', [PostController::class, 'show'])->name('posts.show');
Route::post('/posts/{post}/comments', [CommentController::class, 'store'])->name('comments.store');
Route::get('/posts/{post}/edit', [PostController::class, 'edit'])->name('posts.edit');
// Define the route for updating a post
Route::put('/posts/{post}', [PostController::class, 'update'])->name('posts.update');
Route::delete('/posts/{post}', [PostController::class, 'destroy'])->name('posts.destroy');
Route::post('comments/reply/{comment}', [CommentController::class ,'reply'])->name('comments.reply');
Route::post('posts/like/{post}', [PostController::class, 'like'])->name('posts.like');



/*
Route::get('/posts/create', 'PostController@create')->name('posts.create');
Route::post('/posts', 'PostController@store')->name('posts.store');
Route::get('/posts', 'PostController@index');

Route::get('/', 'PostController@index');
// Route::post('/posts', 'PostController@store');
Route::get('/posts/{post}', 'PostController@show');
Route::post('/posts/{post}/comments', 'CommentController@store');
*/