<?php $__env->startSection('title', 'All Posts'); ?>

<?php $__env->startSection('content'); ?>

   <h1 class="homeheading">All Posts</h1>
   <a href="<?php echo e(route('posts.create')); ?>" class="homenewpost custombutton">Create New Post</a>
   <div class="clear"></div>
    

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post">
            <h2> <strong><?php echo e($post->title); ?></strong> - <small><?php echo e($post->comments_count); ?> comments</small></h2>  
            <p>Author: <?php echo e($post->author); ?></p>
            <p><?php echo e($post->message); ?></p>
            <p>Posted on: <?php echo e($post->post_date); ?></p>
            <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="custombutton">View Details</a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/index.blade.php ENDPATH**/ ?>