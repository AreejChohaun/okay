<?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="comment-reply">
        <p><?php echo e($reply->message); ?></p>
        <p>Posted by: <?php echo e($reply->author); ?></p>
        <!-- <button class="toggle-replies">Show Replies</button>
        <div class="replies">
            <?php echo $__env->make('posts.partials.comment_replies', ['replies' => $reply->replies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div> -->
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/partials/comment_replies.blade.php ENDPATH**/ ?>