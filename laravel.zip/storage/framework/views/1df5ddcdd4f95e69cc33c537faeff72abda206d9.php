

<?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="comment-reply">
        <p><?php echo e($reply->content); ?></p>
        <?php if($reply->user): ?>
            <p>Replied by: <?php echo e($reply->user->name); ?></p>
        <?php else: ?>
            <p>Replied by: Guest</p>
        <?php endif; ?>
        <!-- Display reply button if needed -->
        <button>Show Replies</button>
        <div class="replies">
            <?php echo $__env->make('posts.partials.comment_replies', ['replies' => $reply->replies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\resources\views/comments/partials/comment_replies.blade.php ENDPATH**/ ?>