<?php $__env->startSection('title', $post->title); ?>

<?php $__env->startSection('content'); ?>

    <a class="editpost" href="<?php echo e(route('posts.edit', $post->id)); ?>">Edit Post</a>

    <form class="deletepost" method="POST" action="<?php echo e(route('posts.destroy', $post->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?> <!-- Use DELETE method for deletion -->
        <button type="submit" onclick="return confirm('Are you sure you want to delete this post?')">Delete Post</button>
    </form>

    <a class="backtoposts" href="<?php echo e(route('posts.index')); ?>">Back to All Posts</a>

    <h1><?php echo e($post->title); ?></h1>
    <p>Author: <?php echo e($post->author); ?></p>
    <p><?php echo e($post->message); ?></p>
    <p>Posted on: <?php echo e($post->post_date); ?></p>

    <div class="post">
        <!-- Display post content -->

        <p>Likes: <?php echo e($post->likes ? $post->likes->count() : 0); ?></p>

        <form method="POST" action="<?php echo e(route('posts.like', $post->id)); ?>">
            <?php echo csrf_field(); ?>
            <br>
            <input type="text" name="liker_name" placeholder="Your Name">
            <br>
            <br>

            <button type="submit" class="buttonpadding">Like</button>
        </form>
    </div>

     <div class="comments_add">
        <!-- Comment Creation Form -->
        <h2>Add a Comment</h2>
        <form method="POST" action="<?php echo e(route('comments.store', ['post' => $post->id])); ?>">
            <?php echo csrf_field(); ?>
            <label for="author">Author:</label>
            <input type="text" name="author" id="author" required>

            <label for="message">Comment:</label>
            <textarea name="message" id="message" rows="4" required></textarea>

            <button type="submit" class="buttonpadding">Add Comment</button>
        </form>
    </div>

    <br>


    <h2>Comments:</h2>

    <?php if($comments->count() > 0): ?>
        <ul>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!$comment->parent_comment_id): ?>

                <div class="comment">

                    <p><?php echo e($comment->message); ?></p>
                    <p>Posted by: <?php echo e($comment->author); ?></p>
                    <button class="comment-reply-button" data-toggle-replies>Show Replies</button>
                    <br>
                    <div class="replies" style="display: none;">
                        <?php echo $__env->make('posts.partials.comment_replies', ['replies' => $comment->replies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>

                    <br>
                    <!-- Reply Form -->
                    <form method="POST" action="<?php echo e(route('comments.reply', $comment->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input name="author" class="custominput form-control" placeholder="author" value="<?php echo e(old('author')); ?>" >
                             <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <textarea name="message" class="form-control" rows="3" placeholder="Write a reply"><?php echo e(old('message')); ?></textarea>
                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <input type="hidden" name="parent_comment_id" value="<?php echo e($comment->id); ?>">
                        <button type="submit" class="btn btn-primary buttonpadding" style="display: block;margin: 0 auto;">Reply</button>
                    </form>
                
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php else: ?>
      <p>No comments yet.</p>
    <?php endif; ?>

   

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/show.blade.php ENDPATH**/ ?>