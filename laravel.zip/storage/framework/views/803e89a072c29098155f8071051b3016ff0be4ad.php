<?php $__env->startSection('title', 'Edit Post'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Edit Post</h1>

    <form method="POST" action="<?php echo e(route('posts.update', ['post' => $post->id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> <!-- Use PUT method for updating -->

        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="<?php echo e($post->title); ?>" required>

        <label for="message">Message:</label>
        <textarea name="message" id="message" rows="4" required><?php echo e($post->message); ?></textarea>

        <button type="submit" class="buttonpadding">Update Post</button>
    </form>
<?php $__env->stopSection(); ?>


<!-- extends('layout')

section('title', 'Edit Post')

section('content')
    <h1>Edit Post</h1>

    <form method="POST" action="<?php echo e(route('posts.update', $post->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?>

        <label for="title">Title:</label>
        <input type="text" name="title" id="title" value="<?php echo e($post->title); ?>" required>

        <label for="author">Author:</label>
        <input type="text" name="author" id="author" value="<?php echo e($post->author); ?>" required>

        <label for="message">Message:</label>
        <textarea name="message" id="message" rows="4" required><?php echo e($post->message); ?></textarea>

        <button type="submit">Update Post</button>
    </form>
endsection   -->



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/posts/edit.blade.php ENDPATH**/ ?>